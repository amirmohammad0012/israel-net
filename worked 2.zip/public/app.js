
const state = {
  sessionId: localStorage.getItem("sessionId") || "",
  phone: localStorage.getItem("phone") || "",
  connected: false,
  selectedServer: null,
  favorites: [],
  theme: localStorage.getItem("theme") || "dark",
  onlyFavorites: false,
  connectStart: null,
  timerInterval: null,
  speedInterval: null
};

const screens = {
  onboarding: document.getElementById("onboardingScreen"),
  auth: document.getElementById("authScreen"),
  app: document.getElementById("appScreen")
};
const tabs = {
  home: document.getElementById("tabHome"),
  servers: document.getElementById("tabServers"),
  favorites: document.getElementById("tabFavorites"),
  premium: document.getElementById("tabPremium"),
  settings: document.getElementById("tabSettings")
};

function setTheme() {
  document.body.classList.toggle("light", state.theme === "light");
  localStorage.setItem("theme", state.theme);
  document.querySelectorAll("#themeToggle,#headerThemeBtn").forEach(btn => { if (btn) btn.textContent = state.theme === "light" ? "☾" : "☀"; });
}
setTheme();

function showScreen(name) {
  Object.values(screens).forEach(s => s.classList.remove("active"));
  screens[name].classList.add("active");
}
function showTab(name) {
  Object.values(tabs).forEach(t => t.classList.remove("active"));
  tabs[name].classList.add("active");
  document.querySelectorAll(".nav-item").forEach(btn => btn.classList.toggle("active", btn.dataset.tab === name));
}
function msg(el, text, type="info") {
  el.textContent = text;
  el.className = "message " + type;
}
function formatTime(sec) {
  const m = String(Math.floor(sec / 60)).padStart(2, "0");
  const s = String(sec % 60).padStart(2, "0");
  return m + ":" + s;
}
function speedLabel(p) {
  if (p <= 45) return "Fast";
  if (p <= 90) return "Balanced";
  return "Long Route";
}
function startTimer() {
  stopTimer();
  state.connectStart = Date.now();
  state.timerInterval = setInterval(() => {
    const seconds = Math.floor((Date.now() - state.connectStart) / 1000);
    document.getElementById("connectionTimer").textContent = formatTime(seconds);
  }, 1000);
}
function stopTimer() {
  if (state.timerInterval) clearInterval(state.timerInterval);
  state.timerInterval = null;
  document.getElementById("connectionTimer").textContent = "00:00";
}
function startSpeedMeter() {
  stopSpeedMeter();
  const fill = document.getElementById("meterFill");
  const label = document.getElementById("speedValue");
  state.speedInterval = setInterval(() => {
    const value = state.connected ? Math.floor(35 + Math.random() * 220) : Math.floor(Math.random() * 8);
    fill.style.width = Math.min(100, Math.max(6, Math.floor(value / 2.5))) + "%";
    label.textContent = value + " Mbps";
  }, 850);
}
function stopSpeedMeter() {
  if (state.speedInterval) clearInterval(state.speedInterval);
  state.speedInterval = null;
}

document.getElementById("themeToggle").addEventListener("click", () => { state.theme = state.theme === "light" ? "dark" : "light"; setTheme(); });
document.getElementById("headerThemeBtn").addEventListener("click", () => { state.theme = state.theme === "light" ? "dark" : "light"; setTheme(); });
document.getElementById("settingsThemeBtn").addEventListener("click", () => { state.theme = state.theme === "light" ? "dark" : "light"; setTheme(); });

setTimeout(() => {
  document.getElementById("splashScreen").classList.remove("active");
  if (state.sessionId && state.phone) {
    document.getElementById("profilePhone").textContent = state.phone;
    showScreen("app");
    showTab("home");
    loadFavorites().then(() => loadServers()).then(() => loadStats()).then(loadRecents);
  } else {
    showScreen("onboarding");
  }
}, 1800);

document.getElementById("startBtn").addEventListener("click", () => showScreen("auth"));
document.getElementById("backToOnboarding").addEventListener("click", () => showScreen("onboarding"));

document.getElementById("otpBtn").addEventListener("click", async () => {
  const phone = document.getElementById("phone").value.trim();
  const authMsg = document.getElementById("authMsg");
  const otpPreview = document.getElementById("otpPreview");
  if (!phone) return msg(authMsg, "Enter a phone number first.", "error");
  try {
    const res = await fetch("/api/request-otp", {
      method: "POST", headers: {"Content-Type":"application/json"}, body: JSON.stringify({ phone })
    });
    const data = await res.json();
    if (!res.ok) return msg(authMsg, data.error || "OTP failed.", "error");
    otpPreview.classList.remove("hidden");
    otpPreview.textContent = "Test OTP: " + data.otp;
    msg(authMsg, "OTP generated successfully.", "success");
  } catch {
    msg(authMsg, "Unable to reach server.", "error");
  }
});

document.getElementById("authForm").addEventListener("submit", async (e) => {
  e.preventDefault();
  const phone = document.getElementById("phone").value.trim();
  const otp = document.getElementById("otp").value.trim();
  const accessCode = document.getElementById("accessCode").value.trim();
  const authMsg = document.getElementById("authMsg");
  if (!phone || !otp || !accessCode) return msg(authMsg, "Please complete all fields.", "error");

  try {
    const res = await fetch("/api/verify", {
      method: "POST", headers: {"Content-Type":"application/json"}, body: JSON.stringify({ phone, otp, accessCode })
    });
    const data = await res.json();
    if (!res.ok) return msg(authMsg, data.error || "Login failed.", "error");

    state.sessionId = data.sessionId;
    state.phone = data.phone;
    localStorage.setItem("sessionId", state.sessionId);
    localStorage.setItem("phone", state.phone);
    document.getElementById("profilePhone").textContent = state.phone;

    showScreen("app");
    showTab("home");
    await loadFavorites();
    await loadServers();
    await loadStats();
    await loadRecents();
    startSpeedMeter();
  } catch {
    msg(authMsg, "Server connection error.", "error");
  }
});

async function loadFavorites() {
  if (!state.phone) return;
  const res = await fetch("/api/favorites?phone=" + encodeURIComponent(state.phone));
  const data = await res.json();
  state.favorites = data.favorites || [];
}
async function loadRecents() {
  if (!state.phone) return;
  const res = await fetch("/api/recents?phone=" + encodeURIComponent(state.phone));
  const data = await res.json();
  const wrap = document.getElementById("recentServersList");
  wrap.innerHTML = "";
  const items = data.recents || [];
  if (!items.length) {
    wrap.innerHTML = '<div class="empty-item">No recent servers yet.</div>';
    return;
  }
  items.forEach(item => wrap.appendChild(createServerCard(item)));
}
async function loadServers(query = "", favoritesOnly = false) {
  const url = favoritesOnly
    ? `/api/servers?phone=${encodeURIComponent(state.phone)}&favorites=1&q=${encodeURIComponent(query)}`
    : `/api/servers?q=${encodeURIComponent(query)}`;
  const res = await fetch(url);
  const list = await res.json();

  const serverList = document.getElementById("serverList");
  const favoritesList = document.getElementById("favoritesList");
  serverList.innerHTML = "";
  favoritesList.innerHTML = "";

  if (!list.length && favoritesOnly) {
    favoritesList.innerHTML = '<div class="empty-item">No favorite servers yet.</div>';
  } else if (!list.length) {
    serverList.innerHTML = '<div class="empty-item">No servers found.</div>';
  }

  list.forEach((item, idx) => {
    const card = createServerCard(item);
    if (!favoritesOnly) serverList.appendChild(card);
    if (state.favorites.includes(item.id)) favoritesList.appendChild(createServerCard(item));
    if (!state.selectedServer && idx === 0) selectServer(item);
  });

  if (!favoritesList.innerHTML.trim()) favoritesList.innerHTML = '<div class="empty-item">No favorite servers yet.</div>';
}
function createServerCard(item) {
  const div = document.createElement("div");
  div.className = "server-row" + (state.selectedServer && state.selectedServer.id === item.id ? " selected" : "");
  div.innerHTML = `
    <button class="server-main-btn" type="button">
      <div class="server-main">
        <div class="flag">${item.flag}</div>
        <div class="server-copy">
          <div class="server-country">${item.country}</div>
          <div class="server-city">${item.city} · ${item.region}</div>
        </div>
      </div>
      <div class="server-meta">
        <div class="server-ping">${item.ping} ms</div>
        <div class="meta-inline">
          <span class="pill ${item.status === "Online" ? "pill-green" : "pill-red"}">${item.status}</span>
          ${item.premium ? '<span class="pill pill-gold">PRO</span>' : ''}
        </div>
      </div>
    </button>
    <button class="fav-btn ${state.favorites.includes(item.id) ? "active" : ""}" type="button">★</button>
  `;
  div.querySelector(".server-main-btn").addEventListener("click", () => selectServer(item));
  div.querySelector(".fav-btn").addEventListener("click", () => toggleFavorite(item.id));
  return div;
}
function selectServer(item) {
  state.selectedServer = item;
  document.getElementById("currentPing").textContent = item.ping + " ms";
  document.getElementById("speedClass").textContent = speedLabel(item.ping);
  document.getElementById("routeLabel").textContent = item.city;
  document.getElementById("selectedServerPill").textContent = item.flag + " " + item.country;
  document.querySelectorAll(".server-row").forEach(el => el.classList.remove("selected"));
  document.querySelectorAll(".server-row").forEach(el => {
    if (el.textContent.includes(item.country) && el.textContent.includes(item.city)) el.classList.add("selected");
  });
}
async function toggleFavorite(serverId) {
  if (!state.phone) return;
  const res = await fetch("/api/favorites/toggle", {
    method: "POST", headers: {"Content-Type":"application/json"}, body: JSON.stringify({ phone: state.phone, serverId })
  });
  const data = await res.json();
  state.favorites = data.favorites || [];
  await loadServers(document.getElementById("serverSearchInput").value.trim(), false);
  await loadRecents();
}
async function toggleConnection() {
  if (!state.sessionId) return showScreen("auth");
  if (!state.selectedServer) {
    const res = await fetch("/api/quick-connect");
    const item = await res.json();
    selectServer(item);
  }

  state.connected = !state.connected;
  document.body.classList.toggle("vpn-on", state.connected);
  document.getElementById("connectionText").textContent = state.connected ? "Connected" : "Disconnected";
  document.getElementById("connectionText").className = "connection-state " + (state.connected ? "connected" : "disconnected");
  document.getElementById("connectBtn").classList.toggle("active", state.connected);
  document.getElementById("connectBtnText").textContent = state.connected ? "Tap to Disconnect" : "Tap to Connect";

  if (state.connected) startTimer(); else stopTimer();
  if (!state.speedInterval) startSpeedMeter();

  try {
    await fetch("/api/session/connect", {
      method: "POST",
      headers: {"Content-Type":"application/json"},
      body: JSON.stringify({ sessionId: state.sessionId, connected: state.connected, serverId: state.selectedServer ? state.selectedServer.id : "" })
    });
    await loadStats();
    await loadRecents();
  } catch {}
}
document.getElementById("connectBtn").addEventListener("click", toggleConnection);
document.getElementById("quickConnectBtn").addEventListener("click", async () => {
  const res = await fetch("/api/quick-connect");
  const item = await res.json();
  selectServer(item);
  if (!state.connected) await toggleConnection();
});
document.getElementById("serverSearchInput").addEventListener("input", async (e) => { await loadServers(e.target.value.trim(), false); });
document.getElementById("favoritesFilterBtn").addEventListener("click", async () => {
  state.onlyFavorites = !state.onlyFavorites;
  document.getElementById("favoritesFilterBtn").textContent = state.onlyFavorites ? "Show All Servers" : "Show Favorites Only";
  if (state.onlyFavorites) {
    const res = await fetch(`/api/servers?phone=${encodeURIComponent(state.phone)}&favorites=1&q=${encodeURIComponent(document.getElementById("serverSearchInput").value.trim())}`);
    const list = await res.json();
    const serverList = document.getElementById("serverList");
    serverList.innerHTML = "";
    if (!list.length) serverList.innerHTML = '<div class="empty-item">No favorite servers found.</div>';
    else list.forEach(item => serverList.appendChild(createServerCard(item)));
  } else {
    await loadServers(document.getElementById("serverSearchInput").value.trim(), false);
  }
});
document.querySelectorAll(".nav-item").forEach(btn => btn.addEventListener("click", () => showTab(btn.dataset.tab)));
document.getElementById("logoutBtn").addEventListener("click", () => {
  localStorage.removeItem("sessionId");
  localStorage.removeItem("phone");
  state.sessionId = ""; state.phone = ""; state.connected = false;
  stopTimer(); startSpeedMeter();
  showScreen("auth");
});
async function loadStats() {
  if (!state.phone) return;
  const res = await fetch("/api/stats?phone=" + encodeURIComponent(state.phone));
  const data = await res.json();
  document.getElementById("statSessions").textContent = data.totalConnections;
  document.getElementById("statSecureTime").textContent = data.secureTime;
  document.getElementById("statDataSaved").textContent = data.dataSaved;
  document.getElementById("statOnlineUsers").textContent = data.onlineUsers;
}
setInterval(async () => {
  if (!state.sessionId) return;
  try {
    await fetch("/api/session/ping", {
      method: "POST", headers: {"Content-Type":"application/json"}, body: JSON.stringify({ sessionId: state.sessionId })
    });
  } catch {}
}, 25000);

if ("serviceWorker" in navigator) navigator.serviceWorker.register("./service-worker.js").catch(() => {});
startSpeedMeter();
