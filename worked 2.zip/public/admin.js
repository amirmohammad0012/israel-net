
const state = { adminPin: localStorage.getItem("adminPin") || "" };
const adminPinInput = document.getElementById("adminPin");
const adminLoginBtn = document.getElementById("adminLoginBtn");
const adminLoginMsg = document.getElementById("adminLoginMsg");
const adminPanel = document.getElementById("adminPanel");
const adminLoginCard = document.getElementById("adminLoginCard");
adminPinInput.value = state.adminPin;

function msg(el, text, type="info") { el.textContent = text; el.className = "message " + type; }
function renderList(id, html) { document.getElementById(id).innerHTML = html; }

async function loadAdmin() {
  state.adminPin = adminPinInput.value.trim();
  localStorage.setItem("adminPin", state.adminPin);
  if (!state.adminPin) return msg(adminLoginMsg, "Enter the admin PIN.", "error");
  try {
    const res = await fetch("/api/admin/overview", { headers: { "x-admin-pin": state.adminPin } });
    const data = await res.json();
    if (!res.ok) {
      adminPanel.classList.add("hidden");
      adminLoginCard.classList.remove("hidden");
      return msg(adminLoginMsg, data.error || "Admin login failed.", "error");
    }
    adminPanel.classList.remove("hidden");
    adminLoginCard.classList.add("hidden");
    document.getElementById("statUsers").textContent = data.stats.users;
    document.getElementById("statCodes").textContent = data.stats.codes;
    document.getElementById("statOnline").textContent = data.stats.online;
    document.getElementById("statLogins").textContent = data.stats.logins;

    renderList("onlineUsersList", data.onlineUsers.map(x => `<div class="data-item"><strong>${x.phone}</strong><span>${x.connected ? "Connected" : "Idle"} · ${x.serverName}</span></div>`).join("") || `<div class="data-item">No online users.</div>`);
    renderList("codesList", data.codes.map(x => `<div class="data-item"><strong>${x.code}</strong><span>Used ${x.used}/${x.limit}</span></div>`).join(""));
    renderList("usersList", data.users.map(x => `<div class="data-item"><strong>${x.phone}</strong><span>${new Date(x.verifiedAt || x.createdAt).toLocaleString()}</span></div>`).join(""));
    renderList("logsList", data.logs.map(x => `<div class="data-item"><strong>${x.type} · ${x.phone}</strong><span>${new Date(x.time).toLocaleString()}${x.serverName ? " · " + x.serverName : ""}</span></div>`).join(""));
  } catch {
    msg(adminLoginMsg, "Failed to load dashboard.", "error");
  }
}
adminLoginBtn.addEventListener("click", loadAdmin);
document.getElementById("createCodeBtn").addEventListener("click", async () => {
  const prefix = document.getElementById("codePrefix").value.trim() || "IN";
  const limit = Number(document.getElementById("codeLimit").value || 10);
  const createdCodeMsg = document.getElementById("createdCodeMsg");
  try {
    const res = await fetch("/api/admin/codes", {
      method: "POST",
      headers: { "Content-Type": "application/json", "x-admin-pin": state.adminPin },
      body: JSON.stringify({ prefix, limit })
    });
    const data = await res.json();
    if (!res.ok) return msg(createdCodeMsg, data.error || "Failed to create code.", "error");
    msg(createdCodeMsg, "New code: " + data.code.code, "success");
    await loadAdmin();
  } catch {
    msg(createdCodeMsg, "Request failed.", "error");
  }
});
if (state.adminPin) loadAdmin();
