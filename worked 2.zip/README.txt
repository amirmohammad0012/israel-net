Israel Net v7 - Premium Mobile PWA + Android Source

What is included:
- Splash screen
- Fake live speed meter
- Animated connection timer
- Quick connect
- Recent servers
- Premium subscription page
- Settings page
- Separate admin panel
- Android WebView app source

Run web version:
1) npm install
2) npm start
3) Open http://localhost:3000

Default test values:
- Access Code: ADMIN123
- Admin PIN: 9999

Android source:
- Open the folder android-app in Android Studio
- For Android Emulator, MainActivity is already set to http://10.0.2.2:3000
- If you use a real phone, replace baseUrl in MainActivity.kt with your PC local IP, for example:
  http://192.168.1.10:3000

Important:
This ZIP includes Android source code, not a compiled APK.
