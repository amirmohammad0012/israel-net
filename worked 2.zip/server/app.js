
const express = require("express");
const bodyParser = require("body-parser");
const fs = require("fs");
const path = require("path");
const { v4: uuidv4 } = require("uuid");

const app = express();
const PORT = 3000;

app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, "../public")));

const dataDir = path.join(__dirname, "../data");
const usersFile = path.join(dataDir, "users.json");
const codesFile = path.join(dataDir, "accessCodes.json");
const logsFile = path.join(dataDir, "logs.json");
const favoritesFile = path.join(dataDir, "favorites.json");
const recentsFile = path.join(dataDir, "recents.json");

function readJson(file, fallback) {
  try {
    if (!fs.existsSync(file)) return fallback;
    const raw = fs.readFileSync(file, "utf8");
    if (!raw.trim()) return fallback;
    return JSON.parse(raw);
  } catch {
    return fallback;
  }
}
function writeJson(file, data) {
  fs.writeFileSync(file, JSON.stringify(data, null, 2), "utf8");
}

if (!fs.existsSync(usersFile)) writeJson(usersFile, []);
if (!fs.existsSync(logsFile)) writeJson(logsFile, []);
if (!fs.existsSync(favoritesFile)) writeJson(favoritesFile, {});
if (!fs.existsSync(recentsFile)) writeJson(recentsFile, {});
if (!fs.existsSync(codesFile)) {
  writeJson(codesFile, [
    { id: uuidv4(), code: "ADMIN123", limit: 50, used: 0, expires: null, active: true, createdAt: Date.now() }
  ]);
}

const otpStore = {};
const sessions = {};

const SERVERS = [
  { id: "de-frk", flag: "🇩🇪", country: "Germany", city: "Frankfurt", ping: 39, load: 18, status: "Online", premium: true, region: "Europe" },
  { id: "fr-par", flag: "🇫🇷", country: "France", city: "Paris", ping: 47, load: 26, status: "Online", premium: true, region: "Europe" },
  { id: "nl-ams", flag: "🇳🇱", country: "Netherlands", city: "Amsterdam", ping: 44, load: 21, status: "Online", premium: false, region: "Europe" },
  { id: "uk-lon", flag: "🇬🇧", country: "United Kingdom", city: "London", ping: 51, load: 24, status: "Online", premium: true, region: "Europe" },
  { id: "us-nyc", flag: "🇺🇸", country: "United States", city: "New York", ping: 129, load: 72, status: "Online", premium: true, region: "America" },
  { id: "ca-tor", flag: "🇨🇦", country: "Canada", city: "Toronto", ping: 121, load: 48, status: "Online", premium: false, region: "America" },
  { id: "tr-ist", flag: "🇹🇷", country: "Turkey", city: "Istanbul", ping: 67, load: 33, status: "Online", premium: false, region: "Middle East" },
  { id: "sg-sgp", flag: "🇸🇬", country: "Singapore", city: "Singapore", ping: 161, load: 61, status: "Online", premium: true, region: "Asia" },
  { id: "jp-tok", flag: "🇯🇵", country: "Japan", city: "Tokyo", ping: 178, load: 42, status: "Online", premium: true, region: "Asia" }
];

function getIp(req) {
  const xf = req.headers["x-forwarded-for"];
  if (xf) return String(xf).split(",")[0].trim();
  return req.socket?.remoteAddress || req.ip || "unknown";
}
function adminOnly(req, res, next) {
  const pin = String(req.headers["x-admin-pin"] || "");
  if (pin !== "9999") return res.status(403).json({ error: "Invalid admin PIN" });
  next();
}

app.post("/api/request-otp", (req, res) => {
  const phone = String(req.body.phone || "").trim();
  if (!phone) return res.status(400).json({ error: "Phone number is required" });
  const otp = Math.floor(100000 + Math.random() * 900000).toString();
  otpStore[phone] = { otp, createdAt: Date.now() };
  console.log("OTP for", phone, ":", otp);
  res.json({ ok: true, otp, testMode: true });
});

app.post("/api/verify", (req, res) => {
  const phone = String(req.body.phone || "").trim();
  const otp = String(req.body.otp || "").trim();
  const accessCode = String(req.body.accessCode || "").trim().toUpperCase();

  if (!phone || !otp || !accessCode) return res.status(400).json({ error: "All fields are required" });
  if (!otpStore[phone]) return res.status(400).json({ error: "Request OTP first" });
  if (otpStore[phone].otp !== otp) return res.status(400).json({ error: "Invalid OTP" });

  const codes = readJson(codesFile, []);
  const codeObj = codes.find(c => c.code === accessCode && c.active !== false);
  if (!codeObj) return res.status(400).json({ error: "Invalid access code" });
  if (codeObj.limit && codeObj.used >= codeObj.limit) return res.status(400).json({ error: "Access code limit reached" });
  codeObj.used += 1;
  writeJson(codesFile, codes);

  const users = readJson(usersFile, []);
  let user = users.find(u => u.phone === phone);
  if (!user) {
    user = { id: uuidv4(), phone, createdAt: Date.now(), verifiedAt: Date.now(), totalConnections: 0 };
    users.push(user);
  } else {
    user.verifiedAt = Date.now();
  }
  writeJson(usersFile, users);

  const sessionId = uuidv4();
  sessions[sessionId] = { phone, connected: false, lastSeen: Date.now(), serverId: SERVERS[0].id, connectSince: null };

  const logs = readJson(logsFile, []);
  logs.push({ id: uuidv4(), type: "login", phone, ip: getIp(req), time: Date.now() });
  writeJson(logsFile, logs);

  delete otpStore[phone];
  res.json({ ok: true, sessionId, phone });
});

app.get("/api/servers", (req, res) => {
  const q = String(req.query.q || "").trim().toLowerCase();
  const phone = String(req.query.phone || "").trim();
  const favoritesOnly = req.query.favorites === "1";
  const favorites = readJson(favoritesFile, {});
  let list = SERVERS.slice();

  if (q) {
    list = list.filter(s =>
      s.country.toLowerCase().includes(q) ||
      s.city.toLowerCase().includes(q) ||
      s.region.toLowerCase().includes(q)
    );
  }
  if (favoritesOnly && phone) {
    const favs = favorites[phone] || [];
    list = list.filter(s => favs.includes(s.id));
  }
  res.json(list);
});

app.get("/api/quick-connect", (req, res) => {
  const best = SERVERS.slice().sort((a,b) => a.ping - b.ping || a.load - b.load)[0];
  res.json(best);
});

app.post("/api/favorites/toggle", (req, res) => {
  const phone = String(req.body.phone || "").trim();
  const serverId = String(req.body.serverId || "").trim();
  if (!phone || !serverId) return res.status(400).json({ error: "Missing phone or serverId" });

  const favorites = readJson(favoritesFile, {});
  favorites[phone] = favorites[phone] || [];
  if (favorites[phone].includes(serverId)) {
    favorites[phone] = favorites[phone].filter(id => id !== serverId);
  } else {
    favorites[phone].push(serverId);
  }
  writeJson(favoritesFile, favorites);
  res.json({ ok: true, favorites: favorites[phone] });
});

app.get("/api/favorites", (req, res) => {
  const phone = String(req.query.phone || "").trim();
  const favorites = readJson(favoritesFile, {});
  res.json({ ok: true, favorites: favorites[phone] || [] });
});

app.get("/api/recents", (req, res) => {
  const phone = String(req.query.phone || "").trim();
  const recents = readJson(recentsFile, {});
  const recentIds = recents[phone] || [];
  const items = recentIds.map(id => SERVERS.find(s => s.id === id)).filter(Boolean);
  res.json({ ok: true, recents: items });
});

app.post("/api/session/ping", (req, res) => {
  const sessionId = String(req.body.sessionId || "").trim();
  if (!sessions[sessionId]) return res.status(404).json({ error: "Session not found" });
  sessions[sessionId].lastSeen = Date.now();
  res.json({ ok: true });
});

app.post("/api/session/connect", (req, res) => {
  const sessionId = String(req.body.sessionId || "").trim();
  const connected = !!req.body.connected;
  const serverId = String(req.body.serverId || "").trim();
  const session = sessions[sessionId];
  if (!session) return res.status(404).json({ error: "Session not found" });

  session.connected = connected;
  session.serverId = serverId || session.serverId;
  session.lastSeen = Date.now();
  session.connectSince = connected ? Date.now() : null;

  const server = SERVERS.find(s => s.id === session.serverId) || SERVERS[0];

  const users = readJson(usersFile, []);
  const user = users.find(u => u.phone === session.phone);
  if (user && connected) {
    user.totalConnections = Number(user.totalConnections || 0) + 1;
    writeJson(usersFile, users);
  }

  const recents = readJson(recentsFile, {});
  recents[session.phone] = recents[session.phone] || [];
  recents[session.phone] = [server.id, ...recents[session.phone].filter(id => id !== server.id)].slice(0, 5);
  writeJson(recentsFile, recents);

  const logs = readJson(logsFile, []);
  logs.push({
    id: uuidv4(),
    type: connected ? "connect" : "disconnect",
    phone: session.phone,
    ip: getIp(req),
    serverName: `${server.country} / ${server.city}`,
    time: Date.now()
  });
  writeJson(logsFile, logs);

  res.json({ ok: true, server, connected, connectSince: session.connectSince });
});

app.get("/api/stats", (req, res) => {
  const phone = String(req.query.phone || "").trim();
  const users = readJson(usersFile, []);
  const user = users.find(u => u.phone === phone);
  const now = Date.now();
  const onlineUsers = Object.values(sessions).filter(s => now - s.lastSeen < 120000).length;

  res.json({
    totalConnections: user ? (user.totalConnections || 0) : 0,
    dataSaved: user ? `${(user.totalConnections || 0) * 146} MB` : "0 MB",
    secureTime: user ? `${Math.max(3, user.totalConnections || 0) * 9} min` : "0 min",
    onlineUsers
  });
});

app.get("/api/admin/overview", adminOnly, (req, res) => {
  const users = readJson(usersFile, []);
  const codes = readJson(codesFile, []);
  const logs = readJson(logsFile, []);
  const now = Date.now();

  const onlineUsers = Object.values(sessions)
    .filter(s => now - s.lastSeen < 120000)
    .map(s => {
      const server = SERVERS.find(x => x.id === s.serverId) || SERVERS[0];
      return {
        phone: s.phone,
        connected: s.connected,
        serverName: `${server.country} / ${server.city}`
      };
    });

  res.json({
    stats: {
      users: users.length,
      codes: codes.length,
      online: onlineUsers.length,
      logins: logs.filter(l => l.type === "login").length
    },
    users,
    codes,
    logs: logs.slice().reverse().slice(0, 50),
    onlineUsers
  });
});

app.post("/api/admin/codes", adminOnly, (req, res) => {
  const prefix = String(req.body.prefix || "IN").trim().toUpperCase();
  const limit = Math.max(1, Number(req.body.limit || 1));
  const codes = readJson(codesFile, []);
  const newCode = prefix + Math.random().toString(36).slice(2, 8).toUpperCase();
  const record = { id: uuidv4(), code: newCode, limit, used: 0, expires: null, active: true, createdAt: Date.now() };
  codes.unshift(record);
  writeJson(codesFile, codes);
  res.json({ ok: true, code: record });
});

app.listen(PORT, () => {
  console.log("Israel Net running on http://localhost:" + PORT);
  console.log("Default Access Code: ADMIN123");
  console.log("Default Admin PIN: 9999");
});
